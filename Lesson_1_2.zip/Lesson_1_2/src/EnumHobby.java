enum EnumHobby {
    Paiting,
    Cooking,
    Reading,
    Gargering,
}